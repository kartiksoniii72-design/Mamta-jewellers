const PRODUCTS=[
{id:1,name:"Silver Payal — 85g",metal:"silver",weight:85,making:700,cats:["silver","payal"],desc:"Silver payal • 85 gram",image:"assets/products/payal-85g-marble.jpg"},
{id:2,name:"Silver Payal — 130g",metal:"silver",weight:130,making:700,cats:["silver","payal"],desc:"Silver payal • 130 gram",image:"assets/products/payal-130g-marble.jpg"},
{id:3,name:"Gold Mangalsutra — 18g",metal:"gold",weight:18,making:2000,cats:["gold","necklace"],desc:"Gold mangalsutra • 18 gram",image:"assets/products/mangalsutra-18g-marble.jpg"},
{id:4,name:"Gold Earrings — 13g",metal:"gold",weight:13,making:1000,cats:["gold","earrings"],desc:"Gold earrings • 13 gram",image:"assets/products/earrings-13g-marble.jpg"}];