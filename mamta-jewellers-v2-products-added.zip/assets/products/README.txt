Product photos go in this folder after marble-style e-commerce editing.
Then set the image filename in products.js for each product.