// DAILY RATES — update these two numbers whenever the shop's rate changes.
const SHOP_RATES={
  goldPerGram:14000,
  silverPerGram:240,
  updatedOn:"Today's rate"
};